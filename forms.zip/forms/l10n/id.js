OC.L10N.register(
    "forms",
    {
    "Group" : "Grup",
    "Description" : "Deskrisi",
    "Summary" : "Kesimpulan",
    "Options" : "Pilihan",
    "Settings" : "Setelan",
    "Set expiration date" : "Atur tanggal kedaluwarsa",
    "Expiration date" : "Tanggal kadaluarsa"
},
"nplurals=1; plural=0;");
