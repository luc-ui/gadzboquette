OC.L10N.register(
    "forms",
    {
    "Required" : "Krævet",
    "Searching …" : "Søger ...",
    "Group" : "Gruppe",
    "Description" : "Beskrivelse",
    "Summary" : "Oversigt",
    "Settings" : "Indstillinger",
    "Set expiration date" : "Angiv udløbsdato",
    "Expiration date" : "Udløbsdato",
    "Submit" : "Tilføj"
},
"nplurals=2; plural=(n != 1);");
