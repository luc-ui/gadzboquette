OC.L10N.register(
    "forms",
    {
    "Searching …" : "Recèrca…",
    "Group" : "Grop",
    "Toggle settings" : "Bascular los paramètres",
    "Description" : "Descripcion",
    "Settings" : "Paramètres",
    "Set expiration date" : "Especificar una data d'expiracion",
    "Expiration date" : "Data d'expiracion"
},
"nplurals=2; plural=(n > 1);");
