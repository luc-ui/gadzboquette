OC.L10N.register(
    "forms",
    {
    "Required" : "Requerido",
    "Group" : "Grupo",
    "Description" : "Descripción",
    "Summary" : "Resumen",
    "Settings" : "Configuraciones ",
    "Set expiration date" : "Establecer fecha de expiración",
    "Expiration date" : "Fecha de expiración",
    "Submit" : "Enviar"
},
"nplurals=2; plural=(n != 1);");
