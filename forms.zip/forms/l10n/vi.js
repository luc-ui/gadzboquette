OC.L10N.register(
    "forms",
    {
    "Required" : "Bắt buộc",
    "Group" : "N",
    "Description" : "Mô tả",
    "Summary" : "tóm tắt",
    "Settings" : "Thiết lập",
    "Set expiration date" : "Đặt ngày hết hạn",
    "Expiration date" : "Ngày kết thúc",
    "Submit" : "Gửi đi"
},
"nplurals=1; plural=0;");
