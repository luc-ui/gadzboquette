OC.L10N.register(
    "forms",
    {
    "Required" : "Vereis",
    "Group" : "Groep",
    "Description" : "Beskrywing",
    "Summary" : "Opsomming",
    "Settings" : "Instellings",
    "Set expiration date" : "Stel vervaldatum",
    "Expiration date" : "Vervaldatum"
},
"nplurals=2; plural=(n != 1);");
