OC.L10N.register(
    "forms",
    {
    "Cannot copy, please copy the link manually" : "Ne eblis kopii la ligilon; kopiu ĝin permane.",
    "Required" : "Nepra",
    "No recommendations. Start typing." : "Neniu propono. Ektajpu.",
    "No elements found." : "Nenio trovita.",
    "Group" : "Grupo",
    "Description" : "Priskribo",
    "Summary" : "Resumo",
    "Settings" : "Agordoj",
    "Set expiration date" : "Uzi limdaton",
    "Expiration date" : "Limdato",
    "Submit" : "Sendi"
},
"nplurals=2; plural=(n != 1);");
