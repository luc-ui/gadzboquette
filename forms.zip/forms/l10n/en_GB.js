OC.L10N.register(
    "forms",
    {
    "Required" : "Required",
    "Group" : "Group",
    "Description" : "Description",
    "Summary" : "Summary",
    "Settings" : "Settings",
    "Set expiration date" : "Set expiration date",
    "Expiration date" : "Expiration date",
    "Submit" : "Submit"
},
"nplurals=2; plural=(n != 1);");
