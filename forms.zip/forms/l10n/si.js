OC.L10N.register(
    "forms",
    {
    "Anonymous response" : "නිර්නාමික ප්‍රතිචාරය",
    "responses" : "ප්‍රතිචාර",
    "Group" : "සමූහය",
    "Description" : "විස්තරය",
    "Summary" : "සාරාංශය",
    "Responses" : "ප්‍රතිචාර",
    "Settings" : "සැකසුම්",
    "Date" : "දිනය"
},
"nplurals=2; plural=(n != 1);");
