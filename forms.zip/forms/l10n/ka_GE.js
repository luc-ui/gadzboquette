OC.L10N.register(
    "forms",
    {
    "Required" : "სავალდებულო",
    "Group" : "ჯგუფი",
    "Description" : "აღწერილობა",
    "Summary" : "შეჯამება",
    "Settings" : "პარამეტრები",
    "Set expiration date" : "მიუთითეთ ვადის გასვლის დრო",
    "Expiration date" : "გაუქმების თარიღი",
    "Submit" : "გაგზავნა"
},
"nplurals=2; plural=(n!=1);");
