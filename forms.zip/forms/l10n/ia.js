OC.L10N.register(
    "forms",
    {
    "Required" : "Requirite",
    "Group" : "Gruppo",
    "Description" : "Description",
    "Summary" : "Summario",
    "Settings" : "Configurationes",
    "Set expiration date" : "Assignar data de expiration",
    "Expiration date" : "Data de expiration"
},
"nplurals=2; plural=(n != 1);");
