OC.L10N.register(
    "forms",
    {
    "Required" : "Riquíu",
    "Group" : "Group",
    "Description" : "Descripción",
    "Summary" : "Sumariu",
    "Settings" : "Settings",
    "Set expiration date" : "Afitar la data de caducidá",
    "Expiration date" : "Data de caducidá",
    "Submit" : "Unviar"
},
"nplurals=2; plural=(n != 1);");
