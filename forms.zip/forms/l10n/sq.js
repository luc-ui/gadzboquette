OC.L10N.register(
    "forms",
    {
    "Required" : "E domosdoshme",
    "Group" : "Grup",
    "Description" : "Përshkrim",
    "Summary" : "Përmbledhje",
    "Settings" : "Rregullimet",
    "Set expiration date" : "Caktoni datë skadimi",
    "Expiration date" : "Datë skadimi",
    "Submit" : "Dërgo"
},
"nplurals=2; plural=(n != 1);");
