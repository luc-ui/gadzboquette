OC.L10N.register(
    "forms",
    {
    "Required" : "Nødvendig",
    "Group" : "Gruppe",
    "Description" : "Skildring",
    "Summary" : "Oppsumering",
    "Settings" : "Instillingar",
    "Set expiration date" : "Set utløpsdato",
    "Expiration date" : "Utløpsdato"
},
"nplurals=2; plural=(n != 1);");
