OC.L10N.register(
    "forms",
    {
    "Cannot copy, please copy the link manually" : "Ei saa kopeerida, palun kopeeri link käsitsi",
    "Required" : "Kohustuslik",
    "Searching …" : "Otsin ...",
    "Group" : "Grupp",
    "Description" : "Kirjeldus",
    "Summary" : "Kokkuvõte",
    "Settings" : "Seaded",
    "Set expiration date" : "Määra aegumise kuupäev",
    "Expiration date" : "Aegumise kuupäev"
},
"nplurals=2; plural=(n != 1);");
